// VoiceFile 0.2.0 — WhatsApp uniquement.
// Pendant l'enregistrement d'un vocal, lit un fichier audio choisi à la place du micro.
// Ne s'applique pas aux appels (le micro des appels n'est jamais remplacé).
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <objc/runtime.h>
#include <substrate.h>
#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>

// ───────────── État ─────────────
static volatile int g_on = 0;                       // remplacement actif
static NSData *g_data = nil;                        // fichier PCM mappé en mémoire
static const int16_t *g_pcm = NULL;                 // 24 kHz, mono, int16
static int64_t g_n = 0;
static const double kRate = 24000.0;
static volatile double g_pos = 0;                   // position de lecture (échantillons du fichier)
static volatile uint64_t g_last = 0;
static volatile int g_ended = 0;
static volatile int g_mon = 1;                      // écoute du son pendant l'enregistrement
static volatile int g_monRun = 0, g_monPending = 0, g_monFail = 0;
static volatile double g_monPos = 0;
static volatile uint32_t g_cnt[4] = {0, 0, 0, 0};
static volatile int g_owner = -1; static volatile uint64_t g_ownerT = 0;
static pthread_mutex_t g_mx = PTHREAD_MUTEX_INITIALIZER;

static BOOL vs_claim(int src) {                     // un seul chemin audio à la fois
    uint64_t t = clock_gettime_nsec_np(CLOCK_MONOTONIC);
    int o = g_owner;
    if (o == src || o < 0 || t - g_ownerT > 1000000000ULL) { g_owner = src; g_ownerT = t; return YES; }
    return NO;
}

static void vf_mon_kick(void);
// Fournit `frames` échantillons du fichier (mono, float) à la fréquence `sr`.
// Un nouveau vocal (micro rouvert après > 1,2 s) redémarre le fichier depuis le début.
static void vf_fetch(float *mono, int frames, float sr) {
    uint64_t t = clock_gettime_nsec_np(CLOCK_MONOTONIC);
    if (t - g_last > 1200000000ULL) { g_pos = 0; g_ended = 0; }
    g_last = t;
    const int16_t *pcm = g_pcm; int64_t n = g_n;
    double step = kRate / (double)sr, p = g_pos;
    for (int i = 0; i < frames; i++) {
        int64_t i0 = (int64_t)p;
        if (!pcm || i0 + 1 >= n) {
            mono[i] = 0.f;
            if (!g_ended) { g_ended = 1; dispatch_async(dispatch_get_main_queue(), ^{ AudioServicesPlaySystemSound(kSystemSoundID_Vibrate); }); }
        } else {
            double f = p - (double)i0;
            mono[i] = (float)(((double)pcm[i0] + ((double)pcm[i0 + 1] - (double)pcm[i0]) * f) / 32768.0);
        }
        p += step;
    }
    g_pos = p;
    vf_mon_kick();
}

static int vf_kind(const AudioStreamBasicDescription *a) {
    if (!a || a->mFormatID != kAudioFormatLinearPCM) return 0;
    if ((a->mFormatFlags & kAudioFormatFlagIsFloat) && a->mBitsPerChannel == 32) return 1;
    if (!(a->mFormatFlags & kAudioFormatFlagIsFloat) && a->mBitsPerChannel == 16) return 2;
    return 0;
}
static void vf_write(const float *mono, void *data, int kind, int nch, BOOL planar, int frames) {
    for (int c = 0; c < nch && c < 8; c++) {
        size_t stride = planar ? 1 : (size_t)nch;
        if (kind == 1) {
            float *d = (float *)data + (planar ? (size_t)c * frames : (size_t)c);
            for (int i = 0; i < frames; i++) d[i * stride] = mono[i];
        } else {
            int16_t *d = (int16_t *)data + (planar ? (size_t)c * frames : (size_t)c);
            for (int i = 0; i < frames; i++) { float v = mono[i] * 32767.f; v = v > 32767.f ? 32767.f : (v < -32768.f ? -32768.f : v); d[i * stride] = (int16_t)v; }
        }
    }
}
// Utilisé par AudioQueue et la capture (tampon décrit par un ASBD)
static void vs_process_asbd(void *key, const AudioStreamBasicDescription *a, void *data, UInt32 bytes, int src) {
    g_cnt[src]++;
    if (!g_on || !g_pcm || !data || !a) return;
    int kind = vf_kind(a);
    if (!kind || !vs_claim(src)) return;
    int nch = a->mChannelsPerFrame ? (int)a->mChannelsPerFrame : 1;
    int bps = kind == 1 ? 4 : 2;
    int frames = (int)(bytes / (UInt32)(bps * nch));
    if (frames <= 0 || frames > 8192) return;
    float sr = a->mSampleRate > 8000 ? (float)a->mSampleRate : 44100.f;
    BOOL planar = (a->mFormatFlags & kAudioFormatFlagIsNonInterleaved) != 0;
    float mono[8192];
    vf_fetch(mono, frames, sr);
    vf_write(mono, data, kind, nch, planar, frames);
}

// ── 1) AudioUnit (micro d'une app) — jamais pour les appels (VoiceProcessingIO) ──
typedef struct { void *unit; int kind; float sr; int skip; } UInfo;
static UInfo g_ui[16]; static int g_nui = 0;
static UInfo *ui_for(AudioUnit u) {
    int n = g_nui;
    for (int i = 0; i < n; i++) if (g_ui[i].unit == (void *)u) return &g_ui[i];
    pthread_mutex_lock(&g_mx);
    for (int i = 0; i < g_nui; i++) if (g_ui[i].unit == (void *)u) { pthread_mutex_unlock(&g_mx); return &g_ui[i]; }
    UInfo *ui = (g_nui < 16) ? &g_ui[g_nui] : &g_ui[15];
    AudioStreamBasicDescription d; UInt32 sz = sizeof d; memset(&d, 0, sizeof d);
    int kind = 0;
    if (AudioUnitGetProperty(u, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Output, 1, &d, &sz) == noErr) kind = vf_kind(&d);
    int skip = 0;
    AudioComponent comp = AudioComponentInstanceGetComponent(u);
    AudioComponentDescription cd; memset(&cd, 0, sizeof cd);
    if (comp && AudioComponentGetDescription(comp, &cd) == noErr && cd.componentSubType == kAudioUnitSubType_VoiceProcessingIO) skip = 1;
    ui->unit = (void *)u; ui->kind = kind; ui->skip = skip; ui->sr = d.mSampleRate > 8000 ? (float)d.mSampleRate : 44100.f;
    __sync_synchronize();
    if (g_nui < 16) g_nui++;
    pthread_mutex_unlock(&g_mx);
    return ui;
}
static OSStatus (*orig_render)(AudioUnit, AudioUnitRenderActionFlags *, const AudioTimeStamp *,
                               UInt32, UInt32, AudioBufferList *);
static OSStatus hook_render(AudioUnit unit, AudioUnitRenderActionFlags *flags, const AudioTimeStamp *ts,
                            UInt32 bus, UInt32 frames, AudioBufferList *io) {
    OSStatus r = orig_render(unit, flags, ts, bus, frames, io);
    if (r != noErr || bus != 1 || !io) return r;
    g_cnt[0]++;
    if (!g_on || !g_pcm || frames == 0 || frames > 8192) return r;
    UInfo *ui = ui_for(unit);
    if (!ui || !ui->kind || ui->skip || !vs_claim(0)) return r;
    float mono[8192];
    vf_fetch(mono, (int)frames, ui->sr);
    for (UInt32 b = 0; b < io->mNumberBuffers; b++) {
        AudioBuffer *ab = &io->mBuffers[b];
        if (!ab->mData) continue;
        int nch = ab->mNumberChannels ? (int)ab->mNumberChannels : 1;
        vf_write(mono, ab->mData, ui->kind, nch, NO, (int)frames);
    }
    return r;
}

// ── 2) AudioQueue (beaucoup d'apps d'enregistrement : WhatsApp, etc.) ──
typedef struct { AudioQueueInputCallback cb; void *user; AudioStreamBasicDescription fmt; } AQCtx;
static void aq_cb(void *user, AudioQueueRef q, AudioQueueBufferRef buf, const AudioTimeStamp *ts,
                  UInt32 n, const AudioStreamPacketDescription *d) {
    AQCtx *c = (AQCtx *)user;
    vs_process_asbd((void *)q, &c->fmt, buf->mAudioData, buf->mAudioDataByteSize, 1);
    c->cb(c->user, q, buf, ts, n, d);
}
static OSStatus (*orig_aqNew)(const AudioStreamBasicDescription *, AudioQueueInputCallback, void *,
                              CFRunLoopRef, CFStringRef, UInt32, AudioQueueRef *);
static OSStatus hook_aqNew(const AudioStreamBasicDescription *fmt, AudioQueueInputCallback cb, void *user,
                           CFRunLoopRef rl, CFStringRef mode, UInt32 flags, AudioQueueRef *out) {
    if (fmt && cb && fmt->mFormatID == kAudioFormatLinearPCM) {
        AQCtx *c = (AQCtx *)calloc(1, sizeof(AQCtx));
        c->cb = cb; c->user = user; c->fmt = *fmt;
        return orig_aqNew(fmt, aq_cb, c, rl, mode, flags, out);
    }
    return orig_aqNew(fmt, cb, user, rl, mode, flags, out);
}
static OSStatus (*orig_aqNewQ)(AudioQueueRef *, const AudioStreamBasicDescription *, UInt32,
                               dispatch_queue_t, AudioQueueInputCallbackBlock);
static OSStatus hook_aqNewQ(AudioQueueRef *out, const AudioStreamBasicDescription *fmt, UInt32 flags,
                            dispatch_queue_t q, AudioQueueInputCallbackBlock block) {
    if (fmt && block && fmt->mFormatID == kAudioFormatLinearPCM) {
        AudioStreamBasicDescription f = *fmt;
        AudioQueueInputCallbackBlock w = ^(AudioQueueRef aq, AudioQueueBufferRef buf, const AudioTimeStamp *ts,
                                           UInt32 n, const AudioStreamPacketDescription *d) {
            vs_process_asbd((void *)aq, &f, buf->mAudioData, buf->mAudioDataByteSize, 1);
            block(aq, buf, ts, n, d);
        };
        return orig_aqNewQ(out, fmt, flags, q, w);
    }
    return orig_aqNewQ(out, fmt, flags, q, block);
}

// ── 3) AVCaptureAudioDataOutput (apps caméra / vidéo avec delegate) ──
static NSMutableDictionary *g_capOrig = nil;      // nom de classe -> IMP d'origine
static IMP orig_setDelegate = NULL;
static IMP orig_tap = NULL;

static void vs_process_sample_buffer(void *key, CMSampleBufferRef sb) {
    CMFormatDescriptionRef fd = CMSampleBufferGetFormatDescription(sb);
    if (!fd) return;
    const AudioStreamBasicDescription *a = CMAudioFormatDescriptionGetStreamBasicDescription(fd);
    if (!a || a->mFormatID != kAudioFormatLinearPCM) return;
    CMBlockBufferRef bb = CMSampleBufferGetDataBuffer(sb);
    if (!bb) return;
    size_t len = 0, total = 0; char *p = NULL;
    if (CMBlockBufferGetDataPointer(bb, 0, &len, &total, &p) != kCMBlockBufferNoErr || !p || len != total) return;
    vs_process_asbd(key, a, p, (UInt32)len, 2);
}
static void vs_cap_imp(id self, SEL _cmd, AVCaptureOutput *out, CMSampleBufferRef sb, AVCaptureConnection *conn) {
    if ([out isKindOfClass:AVCaptureAudioDataOutput.class]) vs_process_sample_buffer((__bridge void *)out, sb);
    IMP o = NULL;
    for (Class k = object_getClass(self); k && !o; k = class_getSuperclass(k)) {
        NSValue *v = g_capOrig[NSStringFromClass(k)];
        if (v) o = (IMP)[v pointerValue];
    }
    if (o) ((void (*)(id, SEL, id, CMSampleBufferRef, id))o)(self, _cmd, out, sb, conn);
}
static Class vs_owner(Class c, SEL s) {
    for (Class k = c; k; k = class_getSuperclass(k)) {
        unsigned n = 0; Method *l = class_copyMethodList(k, &n); BOOL f = NO;
        for (unsigned i = 0; i < n; i++) if (method_getName(l[i]) == s) { f = YES; break; }
        free(l);
        if (f) return k;
    }
    return Nil;
}
static void vs_swizzle_delegate(id del) {
    if (!del) return;
    SEL s = @selector(captureOutput:didOutputSampleBuffer:fromConnection:);
    Class owner = vs_owner(object_getClass(del), s);
    if (!owner) return;
    @synchronized ([NSProcessInfo processInfo]) {
        if (!g_capOrig) g_capOrig = [NSMutableDictionary new];
        NSString *name = NSStringFromClass(owner);
        if (g_capOrig[name]) return;
        Method m = class_getInstanceMethod(owner, s);
        if (!m) return;
        g_capOrig[name] = [NSValue valueWithPointer:(void *)method_getImplementation(m)];
        method_setImplementation(m, (IMP)vs_cap_imp);
    }
}
static void vs_setdel_imp(id self, SEL _cmd, id delegate, dispatch_queue_t q) {
    vs_swizzle_delegate(delegate);
    ((void (*)(id, SEL, id, dispatch_queue_t))orig_setDelegate)(self, _cmd, delegate, q);
}

// ── 4) AVAudioEngine : tap sur le micro (inputNode) ──
static void vs_process_pcmbuffer(void *key, AVAudioPCMBuffer *buf) {
    g_cnt[3]++;
    if (!g_on || !g_pcm || !vs_claim(3)) return;
    int n = (int)buf.frameLength, nch = (int)buf.format.channelCount, st = (int)buf.stride;
    if (n <= 0 || n > 8192) return;
    float mono[8192];
    vf_fetch(mono, n, (float)buf.format.sampleRate);
    if (buf.floatChannelData) {
        for (int c = 0; c < nch && c < 8; c++) { float *d = buf.floatChannelData[c]; for (int i = 0; i < n; i++) d[(size_t)i * st] = mono[i]; }
    } else if (buf.int16ChannelData) {
        for (int c = 0; c < nch && c < 8; c++) {
            int16_t *d = buf.int16ChannelData[c];
            for (int i = 0; i < n; i++) { float v = mono[i] * 32767.f; v = v > 32767.f ? 32767.f : (v < -32768.f ? -32768.f : v); d[(size_t)i * st] = (int16_t)v; }
        }
    }
}
static void vs_tap_imp(id self, SEL _cmd, AVAudioNodeBus bus, AVAudioFrameCount size, AVAudioFormat *fmt, AVAudioNodeTapBlock block) {
    AVAudioNodeTapBlock w = block;
    if (block && [self isKindOfClass:NSClassFromString(@"AVAudioInputNode")]) {
        void *key = (__bridge void *)self;
        w = ^(AVAudioPCMBuffer *buf, AVAudioTime *when) { vs_process_pcmbuffer(key, buf); block(buf, when); };
    }
    ((void (*)(id, SEL, AVAudioNodeBus, AVAudioFrameCount, AVAudioFormat *, AVAudioNodeTapBlock))orig_tap)(self, _cmd, bus, size, fmt, w);
}

static void vs_install_objc_hooks(void) {
    static BOOL tapDone = NO, capDone = NO;
    if (!tapDone) {
        Class c = NSClassFromString(@"AVAudioNode");
        Method m = c ? class_getInstanceMethod(c, @selector(installTapOnBus:bufferSize:format:block:)) : NULL;
        if (m) { orig_tap = method_setImplementation(m, (IMP)vs_tap_imp); tapDone = YES; }
    }
    if (!capDone) {
        Class c = NSClassFromString(@"AVCaptureAudioDataOutput");
        Method m = c ? class_getInstanceMethod(c, @selector(setSampleBufferDelegate:queue:)) : NULL;
        if (m) { orig_setDelegate = method_setImplementation(m, (IMP)vs_setdel_imp); capDone = YES; }
    }
}


// ───────────── Écoute : on entend le fichier pendant l'enregistrement ─────────────
static AVAudioEngine *g_eng = nil;
static AVAudioSourceNode *g_srcNode = nil;
static BOOL g_overrode = NO;

static void vf_mon_start(void) {                    // thread principal
    if (g_monRun || !g_mon || !g_on || !g_pcm) return;
    AVAudioSession *s = AVAudioSession.sharedInstance;
    BOOL hp = NO;
    for (AVAudioSessionPortDescription *o in s.currentRoute.outputs) {
        NSString *t = o.portType;
        if ([t isEqualToString:AVAudioSessionPortHeadphones] || [t isEqualToString:AVAudioSessionPortBluetoothA2DP] ||
            [t isEqualToString:AVAudioSessionPortBluetoothHFP] || [t isEqualToString:AVAudioSessionPortBluetoothLE] ||
            [t isEqualToString:AVAudioSessionPortUSBAudio]) hp = YES;
    }
    NSError *e = nil;
    if (!hp) { [s overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:&e]; g_overrode = YES; }   // haut-parleur si pas d'écouteurs
    AVAudioEngine *eng = [AVAudioEngine new];
    AVAudioFormat *fmt = [[AVAudioFormat alloc] initStandardFormatWithSampleRate:kRate channels:1];
    AVAudioSourceNode *node = [[AVAudioSourceNode alloc] initWithFormat:fmt renderBlock:^OSStatus(BOOL *isSilence, const AudioTimeStamp *ts, AVAudioFrameCount frames, AudioBufferList *abl) {
        float *out = (float *)abl->mBuffers[0].mData;
        const int16_t *pcm = g_pcm; int64_t n = g_n;
        uint64_t now = clock_gettime_nsec_np(CLOCK_MONOTONIC);
        BOOL live = g_on && g_mon && pcm && !g_ended && (now - g_last) < 400000000ULL;
        double p = g_monPos, gp = g_pos;
        if (fabs(p - gp) > 12000.0) p = gp;                       // resynchronise avec le micro remplacé
        for (AVAudioFrameCount i = 0; i < frames; i++) {
            int64_t i0 = (int64_t)p;
            if (live && pcm && i0 + 1 < n) {
                double f = p - (double)i0;
                out[i] = (float)(((double)pcm[i0] + ((double)pcm[i0 + 1] - (double)pcm[i0]) * f) / 32768.0);
                p += 1.0;
            } else out[i] = 0.f;
        }
        g_monPos = p;
        *isSilence = live ? NO : YES;
        return noErr;
    }];
    [eng attachNode:node];
    [eng connect:node to:eng.mainMixerNode format:fmt];
    g_monPos = g_pos;
    if ([eng startAndReturnError:&e]) { g_eng = eng; g_srcNode = node; g_monRun = 1; g_monFail = 0; }
    else { g_monFail = 1; if (g_overrode) { [s overrideOutputAudioPort:AVAudioSessionPortOverrideNone error:nil]; g_overrode = NO; } }
}
static void vf_mon_stop(void) {                     // thread principal
    if (!g_monRun) return;
    g_monRun = 0;
    [g_eng stop]; g_eng = nil; g_srcNode = nil;
    if (g_overrode) { [AVAudioSession.sharedInstance overrideOutputAudioPort:AVAudioSessionPortOverrideNone error:nil]; g_overrode = NO; }
}
static void vf_mon_kick(void) {                     // appelé depuis le fil audio du micro
    if (g_mon && g_on && !g_monRun && !g_monPending && !g_ended) {
        g_monPending = 1;
        dispatch_async(dispatch_get_main_queue(), ^{ vf_mon_start(); g_monPending = 0; });
    }
}

// ───────────── Choix du fichier : décodage en PCM 24 kHz mono ─────────────
static NSString *vf_dir(void) { return NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0]; }
static void vf_load_saved(void) {
    NSString *p = [vf_dir() stringByAppendingPathComponent:@"voicefile.pcm"];
    NSData *d = [NSData dataWithContentsOfFile:p options:NSDataReadingMappedAlways error:nil];
    if (d.length > 4800) { g_data = d; g_pcm = (const int16_t *)d.bytes; g_n = (int64_t)(d.length / 2); g_pos = 0; g_ended = 0; }
}
static void vf_import(NSURL *url, void (^done)(NSString *err)) {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        BOOL sec = [url startAccessingSecurityScopedResource];
        ExtAudioFileRef f = NULL;
        OSStatus st = ExtAudioFileOpenURL((__bridge CFURLRef)url, &f);
        if (st != noErr || !f) { if (sec) [url stopAccessingSecurityScopedResource]; dispatch_async(dispatch_get_main_queue(), ^{ done(@"Fichier illisible"); }); return; }
        AudioStreamBasicDescription cf; memset(&cf, 0, sizeof cf);
        cf.mSampleRate = kRate; cf.mFormatID = kAudioFormatLinearPCM;
        cf.mFormatFlags = kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
        cf.mBytesPerPacket = 2; cf.mFramesPerPacket = 1; cf.mBytesPerFrame = 2; cf.mChannelsPerFrame = 1; cf.mBitsPerChannel = 16;
        ExtAudioFileSetProperty(f, kExtAudioFileProperty_ClientDataFormat, sizeof cf, &cf);
        NSString *tmp = [vf_dir() stringByAppendingPathComponent:@"voicefile.tmp"];
        [[NSFileManager defaultManager] createFileAtPath:tmp contents:nil attributes:nil];
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:tmp];
        const UInt32 CH = 65536;
        int16_t *buf = (int16_t *)malloc(CH * 2);
        int64_t total = 0;
        for (;;) {
            AudioBufferList abl; abl.mNumberBuffers = 1;
            abl.mBuffers[0].mNumberChannels = 1; abl.mBuffers[0].mDataByteSize = CH * 2; abl.mBuffers[0].mData = buf;
            UInt32 n = CH;
            if (ExtAudioFileRead(f, &n, &abl) != noErr || n == 0) break;
            [fh writeData:[NSData dataWithBytes:buf length:n * 2]];
            total += n;
        }
        free(buf); [fh closeFile]; ExtAudioFileDispose(f);
        if (sec) [url stopAccessingSecurityScopedResource];
        if (total < 4800) { dispatch_async(dispatch_get_main_queue(), ^{ done(@"Fichier vide ou trop court"); }); return; }
        g_pcm = NULL; usleep(120000);                         // laisse l'audio finir de lire l'ancien fichier
        g_data = nil;
        NSString *dst = [vf_dir() stringByAppendingPathComponent:@"voicefile.pcm"];
        [[NSFileManager defaultManager] removeItemAtPath:dst error:nil];
        [[NSFileManager defaultManager] moveItemAtPath:tmp toPath:dst error:nil];
        vf_load_saved();
        [[NSUserDefaults standardUserDefaults] setObject:url.lastPathComponent forKey:@"vf_name"];
        dispatch_async(dispatch_get_main_queue(), ^{ done(nil); });
    });
}

// ───────────── Interface ─────────────
@interface VFWindow : UIWindow @end
@implementation VFWindow
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)e {
    UIView *v = [super hitTest:p withEvent:e];
    if (v == self || v == self.rootViewController.view) return nil;     // laisse passer les touches vers l'app
    return v;
}
@end

@interface VFRootVC : UIViewController <UIDocumentPickerDelegate>
@property (nonatomic, strong) UIButton *fab;
@property (nonatomic, strong) UIView *panel;
@property (nonatomic, strong) UISwitch *sw, *sw2;
@property (nonatomic, strong) UILabel *nameL, *posL, *msgL;
@property (nonatomic, strong) NSTimer *timer;
@end

static VFWindow *g_win = nil;

@implementation VFRootVC
- (UILabel *)labelAt:(CGRect)r size:(CGFloat)s color:(UIColor *)c lines:(int)n in:(UIView *)v {
    UILabel *l = [[UILabel alloc] initWithFrame:r];
    l.font = [UIFont systemFontOfSize:s]; l.textColor = c; l.numberOfLines = n;
    [v addSubview:l]; return l;
}
- (UIButton *)buttonAt:(CGRect)r title:(NSString *)t action:(SEL)a in:(UIView *)v {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = r; b.backgroundColor = [UIColor colorWithWhite:0.22 alpha:1]; b.layer.cornerRadius = 10;
    b.titleLabel.font = [UIFont systemFontOfSize:14];
    [b setTitle:t forState:UIControlStateNormal];
    [b addTarget:self action:a forControlEvents:UIControlEventTouchUpInside];
    [v addSubview:b]; return b;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.clearColor;
    self.fab = [UIButton buttonWithType:UIButtonTypeCustom];
    self.fab.frame = CGRectMake(16, 230, 52, 52);
    self.fab.backgroundColor = [UIColor colorWithRed:0.1 green:0.55 blue:0.45 alpha:0.92];
    self.fab.layer.cornerRadius = 26;
    self.fab.layer.shadowOpacity = 0.35; self.fab.layer.shadowRadius = 5; self.fab.layer.shadowOffset = CGSizeMake(0, 2);
    [self.fab setTitle:@"🎧" forState:UIControlStateNormal];
    self.fab.titleLabel.font = [UIFont systemFontOfSize:24];
    [self.fab addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [self.fab addGestureRecognizer:[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragFab:)]];
    [self.view addSubview:self.fab];

    UIView *p = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 346)];
    p.backgroundColor = [UIColor colorWithWhite:0.1 alpha:0.96]; p.layer.cornerRadius = 18; p.hidden = YES;
    self.panel = p;
    UILabel *t = [self labelAt:CGRectMake(16, 12, 230, 28) size:19 color:UIColor.whiteColor lines:1 in:p];
    t.text = @"VoiceFile · vocaux"; t.font = [UIFont boldSystemFontOfSize:19];
    UIButton *x = [UIButton buttonWithType:UIButtonTypeSystem]; x.frame = CGRectMake(256, 8, 36, 36);
    [x setTitle:@"✕" forState:UIControlStateNormal];
    [x addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:x];
    UILabel *l1 = [self labelAt:CGRectMake(16, 54, 210, 31) size:15 color:UIColor.whiteColor lines:1 in:p];
    l1.text = @"Lire le fichier à la place du micro";
    self.sw = [[UISwitch alloc] initWithFrame:CGRectMake(235, 54, 51, 31)];
    [self.sw addTarget:self action:@selector(swChanged:) forControlEvents:UIControlEventValueChanged];
    [p addSubview:self.sw];
    UILabel *l2 = [self labelAt:CGRectMake(16, 92, 210, 31) size:15 color:UIColor.whiteColor lines:1 in:p];
    l2.text = @"Écouter pendant l'enregistrement";
    self.sw2 = [[UISwitch alloc] initWithFrame:CGRectMake(235, 92, 51, 31)];
    [self.sw2 addTarget:self action:@selector(sw2Changed:) forControlEvents:UIControlEventValueChanged];
    [p addSubview:self.sw2];
    self.nameL = [self labelAt:CGRectMake(16, 134, 268, 36) size:13 color:[UIColor colorWithWhite:0.85 alpha:1] lines:2 in:p];
    [self buttonAt:CGRectMake(16, 176, 268, 40) title:@"Choisir un fichier audio…" action:@selector(pick) in:p];
    self.posL = [self labelAt:CGRectMake(16, 226, 268, 22) size:15 color:UIColor.whiteColor lines:1 in:p];
    [self buttonAt:CGRectMake(16, 252, 268, 36) title:@"Revenir au début" action:@selector(rewind) in:p];
    self.msgL = [self labelAt:CGRectMake(16, 294, 268, 46) size:11 color:[UIColor colorWithWhite:0.6 alpha:1] lines:3 in:p];
    [self.view addSubview:p];
    [self refresh];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.panel.center = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));
}
static NSString *vf_time(double s) { int a = (int)s; return [NSString stringWithFormat:@"%d:%02d", a / 60, a % 60]; }
- (void)refresh {
    if (!self.sw) return;
    self.sw.on = g_on; self.sw2.on = g_mon;
    NSString *nm = [[NSUserDefaults standardUserDefaults] stringForKey:@"vf_name"];
    self.nameL.text = g_pcm ? [NSString stringWithFormat:@"Fichier : %@", nm ?: @"(audio)"] : @"Aucun fichier choisi";
    double tot = (double)g_n / kRate, pos = MIN((double)g_pos / kRate, tot);
    self.posL.text = g_pcm ? [NSString stringWithFormat:@"Lecture : %@ / %@", vf_time(pos), vf_time(tot)] : @"";
    if (g_monFail && g_mon && g_on) self.msgL.text = @"Écoute impossible dans ce vocal (WhatsApp bloque le son pendant l'enregistrement). Le remplacement du micro fonctionne quand même ; la vibration t'avertit à la fin.";
    else if (g_ended) self.msgL.text = @"Terminé : arrête l'enregistrement du vocal (le téléphone a vibré).";
    else self.msgL.text = @"Active, puis enregistre un vocal dans WhatsApp : le fichier est lu depuis le début. Aucun effet pendant les appels. Il vibre à la fin.";
    self.fab.alpha = g_on ? 0.95 : 0.5;
}
- (void)togglePanel {
    self.panel.hidden = !self.panel.hidden;
    [self.timer invalidate]; self.timer = nil;
    [self refresh];
    if (!self.panel.hidden) {
        __weak typeof(self) ws = self;
        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *tm) { [ws refresh]; }];
    }
}
- (void)dragFab:(UIPanGestureRecognizer *)g {
    CGPoint tr = [g translationInView:self.view];
    CGPoint c = CGPointMake(self.fab.center.x + tr.x, self.fab.center.y + tr.y);
    CGRect b = self.view.bounds;
    c.x = MAX(26, MIN(b.size.width - 26, c.x)); c.y = MAX(60, MIN(b.size.height - 60, c.y));
    self.fab.center = c; [g setTranslation:CGPointZero inView:self.view];
}
- (void)swChanged:(UISwitch *)s {
    g_on = s.on ? 1 : 0;
    [[NSUserDefaults standardUserDefaults] setBool:g_on forKey:@"vf_on"];
    g_pos = 0; g_ended = 0;
    if (!g_on) vf_mon_stop();
    [self refresh];
}
- (void)sw2Changed:(UISwitch *)s {
    g_mon = s.on ? 1 : 0;
    [[NSUserDefaults standardUserDefaults] setBool:g_mon forKey:@"vf_mon"];
    if (!g_mon) vf_mon_stop();
    [self refresh];
}
- (void)rewind { g_pos = 0; g_ended = 0; [self refresh]; }
- (void)pick {
    UIDocumentPickerViewController *pk = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.audio"] inMode:UIDocumentPickerModeImport];
    pk.delegate = self;
    [self presentViewController:pk animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)c didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    if (!urls.count) return;
    self.msgL.text = @"Conversion du fichier en cours…";
    __weak typeof(self) ws = self;
    vf_import(urls.firstObject, ^(NSString *err) {
        [ws refresh];
        if (err) ws.msgL.text = err;
    });
}
@end

static void vf_show_ui(void) {
    if (g_win) return;
    UIWindowScene *scene = nil;
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes)
        if ([sc isKindOfClass:UIWindowScene.class] && sc.activationState == UISceneActivationStateForegroundActive) { scene = (UIWindowScene *)sc; break; }
    if (scene) g_win = [[VFWindow alloc] initWithWindowScene:scene];
    else       g_win = [[VFWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    g_win.windowLevel = UIWindowLevelAlert + 100;
    g_win.backgroundColor = UIColor.clearColor;
    g_win.rootViewController = [VFRootVC new];
    g_win.hidden = NO;
}

// ───────────── Initialisation ─────────────
%ctor {
    @autoreleasepool {
        NSString *path = NSBundle.mainBundle.bundlePath ?: @"";
        if (![path hasSuffix:@".app"]) return;                     // pas d'extensions
        vf_load_saved();
        [[NSUserDefaults standardUserDefaults] registerDefaults:@{@"vf_mon": @YES}];
        g_on = [[NSUserDefaults standardUserDefaults] boolForKey:@"vf_on"] ? 1 : 0;
        g_mon = [[NSUserDefaults standardUserDefaults] boolForKey:@"vf_mon"] ? 1 : 0;
        [NSTimer scheduledTimerWithTimeInterval:0.5 repeats:YES block:^(NSTimer *tm) {      // coupe l'écoute 1,5 s après la fin du vocal
            if (g_monRun && (clock_gettime_nsec_np(CLOCK_MONOTONIC) - g_last) > 1500000000ULL) vf_mon_stop();
        }];
        MSHookFunction((void *)AudioUnitRender, (void *)hook_render, (void **)&orig_render);
        MSHookFunction((void *)AudioQueueNewInput, (void *)hook_aqNew, (void **)&orig_aqNew);
        MSHookFunction((void *)AudioQueueNewInputWithDispatchQueue, (void *)hook_aqNewQ, (void **)&orig_aqNewQ);
        vs_install_objc_hooks();
        [NSNotificationCenter.defaultCenter addObserverForName:UIApplicationDidBecomeActiveNotification
            object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) { vs_install_objc_hooks(); vf_show_ui(); }];
    }
}
